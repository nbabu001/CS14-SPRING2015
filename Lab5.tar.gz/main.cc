//Nishanth Babu
//SID: 861155514
//5/10/15
#include <iostream>
#include "lab5.h"
int main(){
    BST <int>t1;
    cout << "testcase: 1" << endl;
    t1.insert(50);
    t1.insert(20);
    t1.insert(10);
    t1.insert(40);
    t1.insert(35);
    t1.insert(45);
    t1.insert(60);
    t1.insert(70);
    cout << "Part 1" << endl;
    t1.minCover();
    t1.displayMinCover();
    cout << "Part 2" << endl;
    t1.findSumPath(80);
    cout << "Part 3" << endl;
    t1.vertSum();
    cout << endl;
    return 0;
}