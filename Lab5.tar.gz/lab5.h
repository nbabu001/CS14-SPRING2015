//Nishanth Babu
//SID:861155514
//5/10/15

#ifndef lab5_h
#define lab5_h
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <vector>
#include <math.h>
using namespace std;
#define nil 0
template < typename Value >
class BST {
    class Node { // binary tree node
     public:
      Node* left;
      Node* right;
      Value value;
      bool isSelect;
      Node( const Value v = Value() )
       : left(nil), right(nil), value(v), isSelect(false)
      { }
      Value& content() { return value; }
      bool isInternal() { return left != nil && right != nil; }
      bool isExternal() { return left != nil || right != nil; }
      bool isLeaf() { return left == nil && right == nil; }
      int height() { // done
          if (isLeaf() == true){
                 return 0;
             }
             return 1;
          }
          
      int size() {
          if (isExternal()){
                 return 2;
             }
             else if (isLeaf()){
                 return 1;
             }
            return 3;
          }
    }; 

    Node* root;
    int count;
    vector<Node*> v;
    
    public:
     int size() { // find size of whole tree
         if (root == nil){
             cout << "Error: Nothing in tree.";
             return 0;
         }
         return helpsize(root);
     }
     int helpsize(Node* x){
        if(x == nil){
            return 0;
        }
        int sz = 1;
            sz = sz + helpsize(x->left);
            sz = sz + helpsize(x->right);
            return sz;
    }
     
// the functions for lab 5 below

     void minCover(){
         minCover(root->left); // calls on left of root
         minCover(root->right); // calls on right of root
     }
     
     void minCover(Node *temp){ // recursive helper function
         if (temp == nil){
             return;
         }
         minCover(temp->left); // checks the left
         if (temp->size() > 1) // if node is more than one then pushes value into vector
         {
             v.push_back(temp);
             temp->isSelect = true;
         }
         
         minCover(temp->right); // checks the right
     }
     
     void displayMinCover(){ //displays values
         int i;
         for (i = 0; i < v.size(); i++){
             cout << v.at(i)->value << ' ';
         }
         cout << endl;
         cout << i << endl;
     }
     
     void printSum(int buffer[], int sz){
         int temporary;
         int y;
         int x;
         for(int i = 1; i <= sz; i++){//this sorts the array
              for(y = i + 1; y <= sz; y++) {
                   if (buffer[y] > buffer[i]){
                      temporary = buffer[i];
                      buffer[i] = buffer[y];
                      buffer[y] = temporary;
                   }
              }
         }
         for (x = sz; x > 0; x--){
             cout << buffer[x] << ' ';
         }
         cout << endl;
     }
     void findSumPath(Node* n, int sum, int buffer[], int loc, bool &isFound){// finds best path
         if (n == nil){
             return;
         }
         buffer[++loc] = n->value; 
         if (n->isLeaf()){
             int num = 0;
             int x;
             for (x = 1; x <= loc; x++){
                 num = num + buffer[x];
             }
             if (num == sum){ // the path is found
                 isFound = true; 
                 printSum(buffer, loc);
             }
             loc = 1; // make location back to start
         }
         if (!isFound){ // this checks if the path has not been found checks both right and left
             findSumPath(n->left, sum, buffer, loc, isFound);
             if (!isFound){
                findSumPath(n->right, sum, buffer, loc, isFound);
             }
         }
      }
     void findSumPath(int sum){
         int loc1 = 0;
         int buffarray[1000];
         bool isFound = false; 
         if (root == nil){
             cout << '0';
             return;
         }
         if (root->value == sum){
             cout << root->value;
             return;
         }
         findSumPath(root, sum, buffarray, loc1, isFound);
         if (!isFound){
             cout << "0" << endl;
         }
     }
     
     void vertSum(Node* node, int hd, std::map<int, int>& m){
         m[hd] = m[hd] + node->value;
         if (node->right != nil){
             ++hd;
             vertSum(node->right, hd, m);
             --hd;
         }
         if (node->left != nil){
             --hd;
             vertSum(node->left, hd, m);
             ++hd;
         }
         return;
     }
     void displayVertSum(map<int, int> m){ // displays vert sum
         map<int,int>::iterator mp = m.begin();
         for (; mp != m.end(); ++mp)
         {
             cout << m[mp->first] << ' ';
         }
     }
     void vertSum(){
         if (root == nil){
             cout << '0';
             return;
         }
         map<int, int> newmap;
         vertSum(root, 0, newmap);
         displayVertSum(newmap);
     }
     
// Other functions from bst assignment
     
      bool empty() { return size() == 0; }
    void print_node( const Node* n ) {
        cout << n->value <<endl;
// Print the node’s value.
// FILL IN
    }
    bool searchhelp( Value y, Node * z){
        bool find = false;
             if ( z == nil ){
                return false;
             }
             else if ( z->value == y){
                return true;
             }
             find = searchhelp(y, z->right);
             if(!find){
                 find = searchhelp(y,z->left);
             }
             return find;
          }
          
    bool search ( Value x ) {
        if(root == nil){
            return false;
        }
        return searchhelp(x, root);
        
    }
    void preorderhelp(Node * z) const{
        if(z == nil){
            return;
        }
        Node*temp = z;
        cout<<temp->value<<endl;
        preorderhelp(temp->left);
        preorderhelp(temp->right);
    }
    void preorder()const {
        if(root == nil){
            return;
        }
        preorderhelp(root);
    }
    void postorderhelp(Node * z)const{
        if(z ==nil){
            return ;
        }
        Node*temp = z;
        // print_node(temp);
        postorderhelp(temp->left);
        postorderhelp(temp->right);
        cout<<temp->value<<endl;
    }
    void postorder()const {
        if(root == nil){
            return ;
        }
        postorderhelp(root);
    }
    void inorderhelp(Node * z)const{
        if(z==nil){
            return;
        }
        Node*temp = z;
        // print_node(temp);ee
        inorderhelp(temp->left);
        cout<<temp->value<<endl;
        inorderhelp(temp->right);
        // print_node(temp);
    }
    void inorder()const {
        if(root == nil){
            return;
        }
        inorderhelp(root);
    }
    void operatorhelp(vector<Node*> & nodevector, Node*z)const{
        if(z == nil){
            return;
        }
        operatorhelp(nodevector, z->left);
        nodevector.push_back(z);
        operatorhelp(nodevector, z->right);
    }
    Value& operator[] (int n){
        Node* temp = root;
        if(temp == nil){
             exit(-1);
         }
         if(!(n<size())){
             cout<<"Error "<< n<<" is out of bounds"<<endl;
             exit(-1);
         }
          vector<Node*> vectorvalue;
          operatorhelp(vectorvalue,root);
          return vectorvalue.at(n)->value;
// returns reference to the value field of the n-th Node.
// FILL IN
    }
    BST() : root(nil), count(0) {}
    void insert( Value X ) { root = insert( X, root ); }
    Node* insert( Value X, Node* T ) {
// The normal binary-tree insertion procedure ...
    if ( T == nil ) {
        T = new Node( X ); // the only place that T gets updated.
    } 
    else if ( X < T->value ) {
        T->left = insert( X, T->left );
    }
    else if ( X > T->value ) {
        T->right = insert( X, T->right );
    }
    else {
        T->value = X;
}
// later, rebalancing code will be installed here

return T;
}
    void remove( Value X ) { root = remove( X, root ); }
    Node* remove( Value X, Node*& T ) {
// The normal binary-tree removal procedure ...
// Weiss’s code is faster but way more intricate.
    if ( T != nil ) {
        if ( X > T->value ) {
            T->right = remove( X, T->right );
        }
        else if ( X < T->value ) {
            T->left = remove( X, T->left );
        }
        else {
// X == T->value
            if ( T->right != nil ) {
                Node* x = T->right;
            while ( x->left != nil ) x = x->left;
            T->value = x->value; // successor’s value
            T->right = remove( T->value, T->right );
            }
            else if ( T->left != nil ) {
            Node* x = T->left;
            while ( x->right != nil ) x = x->right;
            T->value = x->value; // predecessor’s value
            T->left = remove( T->value, T->left );
            }
            else { // *T is external
                delete T;
                T = nil; // the only updating of T
            }
        }
    }
// later, rebalancing code will be installed here
return T;
}
void okay( ) { okay( root ); }
void okay( Node* T ) {
// diagnostic code can be installed here
return;
}
}; // BST
#endif