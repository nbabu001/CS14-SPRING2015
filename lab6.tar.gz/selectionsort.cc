// Nishanth Babu
// SID : 861155514
// 5/17/15
#include <iostream>
#include <list>
#include <algorithm>
#include <vector> 
#include <utility>
using namespace std;
template <typename L>
void selectionsort (L &l){
    typename L::iterator nextone;
    typename L::iterator current = l.begin();
    if (l.begin() == l.end()) // checks for size of 1
    {
        cout << "Error: size 1" << endl;
        return;
    }
    if (l.size() == 0){ // checks for something in the container
        cout << "Error: size 0" << endl;
        return;
    }
    while(current != l.end()){
        typename L::iterator min = current;
        bool Swap = false;
        nextone = current;
        ++nextone;
        while(nextone != l.end()){ // finds lowest value
            if (*nextone < *min){
                min = nextone;
                Swap = true;
            }
            nextone++;
        }
        if (Swap){//swaps values
            swap(*current, *min);
        }
        current++;
    }
}

int main(){
    pair <int, char> p1;
    list <pair<int, char>> l2;
    
    p1 = make_pair (1,'A');
    l2.push_back(p1);
    p1 = make_pair (5,'b');
    l2.push_back(p1);
    p1 = make_pair (-1,'c');
    l2.push_back(p1);
    p1 = make_pair (0,'d');
    l2.push_back(p1);
    p1 = make_pair (2,'f'); 
    l2.push_back(p1);
    p1 = make_pair (1,'B'); 
    l2.push_back(p1);
    cout << "pre: ";
    for (auto it = l2.begin(); it != l2.end(); ++it){
        cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    }
    cout << endl;
    selectionsort(l2);
    cout << "post: ";
    for (auto it = l2.begin(); it != l2.end(); ++it){
        cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    }
    cout << endl;
    return 0;
}