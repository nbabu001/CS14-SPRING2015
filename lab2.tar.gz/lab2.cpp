//nishanth babu
//861155514
//4/20/2015
#include <forward_list>
#include <iostream>
#include "lab2.h"
using namespace std;
int main()
{
    
    List <int> l1;
    l1.push_front(96);
    l1.push_front(28);
    l1.push_front(47);
    l1.push_front(36);
    l1.push_front(15);
    l1.push_front(47);
    l1.push_front(38);
    l1.push_front(25);
    l1.push_front(81);
    cout << l1.totallength() << endl;
    l1.display();
    cout << endl;
    l1.push_back(114);
    l1.push_back(1341);
    l1.push_back(12);
    l1.push_back(163);
    l1.push_back(14);
    l1.push_back(50);
    l1.push_back(16);
    cout << l1.totallength() << endl;
    l1.display();
    cout << endl;
    l1.elementSwap(1);
    l1.display();
    cout << endl;
    l1.elementSwap(2);
    l1.display();
    cout << endl;
    l1.elementSwap(3);
    l1.display();
    cout << endl;
    l1.elementSwap(4);
    l1.display();
    cout << endl;
    l1.elementSwap(15);
    l1.display();
    cout << endl;
    l1.elementSwap(0);
    l1.display();
    cout << endl;
    l1.elementSwap(16);
    l1.display();
    cout << endl;
    l1.elementSwap(17);
    l1.display();
    cout << endl;
    
    
    return 0;
}