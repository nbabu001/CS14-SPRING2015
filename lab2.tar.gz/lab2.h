//nishanth babu
//861155514
//4/20/2015
#ifndef lab2_h
#define lab2_h
#include<vector>
#include<iostream>
#include<forward_list>
using namespace std;

bool isPrime(int i){
    if(i==1){
        return false;
    }
    for(int x = 2; x < i; x++){
        if(i % x == 0){
            return false;
        }
    }
    return true;
}

int primeCount(forward_list <int> lst){
    if(lst.empty()){
        return 0;
    }
    forward_list<int>::iterator y;
    y = lst.begin();
    int num =0;
    if(isPrime(*y)){
        num++;
    }
    lst.pop_front();
    return primeCount(lst)+num;
}
template< typename Type>
struct Node{
    Type value;
    Node * next;
    Node(Type value)
     : value(value), next(0)
     {}
};

template <class Type>
class List{
    private:
    Node<Type> *head;
    Node<Type> *tail;
    int sz;
    public:
    List();
    List(const List & lst);
    ~List();
    int totallength();
    void display();
    void push_back(Type value);
    void push_front(Type value);
    void pop_front();
    void pop_back();
    void elementSwap(int place);
    List<Type>& operator =(const List<Type>& lst);
    
};
template <class Type>
List<Type>::List(){
    head = 0;
    tail = 0;
    sz = 0;
}
template <class Type>
List<Type>::List(const List& lst){
    head = 0;
    tail = 0;
    sz = 0;
    Node <Type> *current = lst.head;
    
    if (current == 0)
    {
        return;
    }
    
    do{ 
        push_back(current->value);
        current = current->next;
    } while (current != 0);
}
template <class Type>
List<Type>::~List(){
    if (head == 0){
        return;
    }
    do{
        pop_back();
    }while(head != 0);
}
template <class Type>
int List<Type>::totallength(){
    return sz;
}

template <class Type>
void List<Type>::display(){
    if (head == 0){
        cout << "This is an empty list"<<endl;
        return;
    }
    Node<Type> *current = head;
    cout << current->value; 
    current = current->next;
    
    while (current != 0){
        cout << ' ' << current->value;
        current = current->next;
    }
}

template <class Type>
void List<Type>::push_front(Type value){
    Node <Type> *temporary = new Node<Type> (value);
    temporary->next = head;
    head = temporary;
    if (tail == 0){
        tail = head;
    }
    
    ++sz;
}

template <class Type>
void List<Type>::push_back(Type value)
{
    Node <Type> *temporary = new Node<Type>(value);
    if (tail == 0){
        head = temporary;
        tail = temporary;
    }
    
    tail->next = temporary;
    tail = temporary;
    
    ++sz;
}

template <class Type>
void List<Type>::pop_front()
{
    if (head == 0){
        cout << "No Nodes in list"<<endl;
        return;
    }
    Node <Type> *temporary = head->next;
    delete head;
    head = temporary;
    if (head == 0){
        tail = 0;
    }
    --sz;
}

template <class Type>
void List<Type>::pop_back()
{
    if (head == 0){
        cout << "No nodes in the list"<< endl;
        return;
    }
    if (head == tail){
        delete head;
        head = 0;
        tail = 0;
        --sz;
        return;
    }
    Node <Type> *current = head;
    int num = 1; 
    while (num < sz - 1) {
        current = current->next;
        ++num;
    }
    delete tail;
    current->next = 0;
    tail = current;
    --sz;
}

template <class Type>
void List<Type>::elementSwap(int position){
    if (sz == position) {
        cout << "sorry no element there " << position + 1 << endl;
        return;
    }
    if (position <= 0 || position > sz) {
        cout << "sorry no element there " << position << endl;
        return;
    }
    Node <Type> *current = head; 
    int num = 1; 
    while (num < position){
        current = current->next;
        ++num;
    }
    Node <Type> *after = current->next; 
    if (position == 1){
        current->next = after->next;
        after->next = current;
        head = after;
        if (current->next == 0){
            tail = current;
        }
        return;
    }
    Node <Type> *pred = head; 
    num = 1; 
    while (num < position - 1){
        pred = pred->next;
        ++num;
    }
    current->next = after->next;
    after->next = current;
    pred->next = after;
    if (current->next == 0) {
        tail = current;
    }
    return;
}

template <class Type>
List<Type>& List<Type>::operator=(const List<Type>& lst)
{
    if (this != &lst && lst.head != 0) 
    {                                  
        Node <Type> *current = lst.head;
        if (head == 0) {
            do{
                push_back(current->value);
                current = current->next;
            }while (current != 0);
            return *this;
        }
        while (head != 0) {
            pop_back();
        }
        do{
            push_back(current->value);
            current = current->next;
        } while (current != 0);
        return *this;
    }
    while (head != 0){
        pop_back();
    }
    return *this;
}

template <typename Type>
void listCopy(forward_list <Type> L, forward_list <Type> &P)
{
    vector <Type> temporary; 
    typename forward_list<Type>::iterator i = L.begin();

    while (i != L.end()) 
    {
        temporary.push_back(*i);
        ++i;
    }
    i = P.begin();
    unsigned x = 0;
    while (x != temporary.size()) 
    {
        P.push_front(temporary.at(x));
        ++x;
    }
}

template <typename Type>
void printLots (forward_list <Type> L, forward_list <int> P)
{
    forward_list <int>::iterator i; 
    typename forward_list <Type>::iterator s; 
    int sz = 0;
    while (s != L.end()){
        ++sz; 
        ++s;
    }
    for (i = P.begin(); i != P.end(); ++i)
    {
        if (*i > sz || *i == 0) {
            cout << "sorry element " << *i << " is out of bounds " << endl;
            return;
        }
    }
    for (i = P.begin(); i != P.end(); ++i){
        typename forward_list <Type>::iterator l = L.begin(); 
        int num = 1; 
        while (num < *i) {
            ++l;
            ++num;
        }
        cout << *l << endl; 
    }
}
#endif
