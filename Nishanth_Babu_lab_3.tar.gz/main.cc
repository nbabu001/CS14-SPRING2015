//nishanth babu
//sid:861155514
//monday 2-4
#include <iostream>
#include "lab3.h"

using namespace std;

int main()
{
    // // part one test
    //  TwoStackFixed<int> t1(11, 6);
    
    // // t1.popStack1() end cases
    // // t1.popStack2() End cases

    
    // t1.pushStack1(0);
    
    // t1.pushStack1(1);
    
    // t1.pushStack1(2);
   
    // t1.pushStack1(3);
   

    
    // cout << "1: " << t1.popStack1() << endl;
    // cout << "2: " << t1.popStack1() << endl;
    // cout << "3: " << t1.popStack1() << endl;
   
    
    
    // t1.pushStack2(1);
    // t1.pushStack2(3);
    // t1.pushStack2(2);
    
    // cout << "4: " << t1.popStack2() << endl;
    // cout << "5: " << t1.popStack2() << endl;
    // cout << "6: " << t1.popStack2() << endl;
  
    
    //part 2 test cases
    
    // TwoStackOptimal<char> t1(13);
    // //  //t1.popFlexStack1(); // end cases
    // // //  t1.popFlexStack2(); //end cases
    // t1.pushFlexStack1('x'); // 0
    // t1.pushFlexStack1('y'); // 1
    // t1.pushFlexStack1('z'); // 2
    // t1.pushFlexStack1('a'); // 3
    
    // t1.pushFlexStack2('d'); // 9
    // t1.pushFlexStack2('a'); // 8
    // t1.pushFlexStack2('m'); // 7
    // t1.pushFlexStack2('y'); // 6
   
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    
    
    // Part 3 test case
    
    // stack<string> pA;
    // stack<string> pB;
    // stack<string> pC;
    // pA.push("three");
    // pA.push("two");
    // pA.push("one");
    // showTowerStates(3, pA, pB, pC);
    // while(!pC.empty())
    // {
    //     cout << pC.top() << endl;
    //     pC.pop();
    // }
    
    return 0;
}