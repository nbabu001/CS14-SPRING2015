//Nishanth Babu
//SID: 861155514
//Monday 2-4
#ifndef lab3_h
#define lab3_h
#include <iostream>
#include <stack>
using namespace std;
template <class T>
class TwoStackFixed{
    private: 
     int sizeArr;
     int stackone;
     int firststack;
     int stacktwo;
     int secondstack;
     int max;
     T *array;
     bool isFullStack1();
     bool isFullStack2();
     bool isEmptyStack1();
     bool isEmptyStack2();
    public:
     TwoStackFixed(int size, int maxtop);
     T popStack1();
     void pushStack1(T value);
     T popStack2();
     void pushStack2(T value);
};
template <class T>
TwoStackFixed<T>::TwoStackFixed(int size, int maxtop)
 : sizeArr(size), stackone(0), firststack(0), stacktwo(0), secondstack(0), 
   max(maxtop - 1), array(0)
{
    stackone = maxtop;
    stacktwo = sizeArr - maxtop;
    array = new T[sizeArr];
}
template <class T>
bool TwoStackFixed<T>::isFullStack1(){
    if (firststack >= stackone){
        return true;
    }
    return false;
}

template <class T>
bool TwoStackFixed<T>::isFullStack2(){
    if (secondstack >= stacktwo){
        return true;
    }
    return false;
}

template <class T>
bool TwoStackFixed<T>::isEmptyStack1(){
    if (firststack != 0){
        return false;
    }
    return true;
}

template <class T>
bool TwoStackFixed<T>::isEmptyStack2(){
    if (secondstack != 0){
        return false;
    }
    
    return true;
}
template <class T>
void TwoStackFixed<T>::pushStack1(T value){
    if (isFullStack1()){
        cout << "Error: the first stack is full" << endl;
        return;
    }
    array[firststack] = value;
    firststack++;
}
template <class T>
void TwoStackFixed<T>::pushStack2(T value){
    if (isFullStack2()){
        cout << "error: first stack is full" << endl;
        return;
    }
    array[sizeArr - 1 - secondstack] = value;
    secondstack++;
}
template <class T>
T TwoStackFixed<T>::popStack1(){
    T temporary;
    if(isEmptyStack1()){
        cout << "error: the stack is empty";
        exit(1);
    }
    temporary = array[firststack - 1];
    firststack--;
    return temporary;
}
template <class T>
T TwoStackFixed<T>::popStack2(){
    T temporary;
    if (isEmptyStack2()){
        cout << "error: this stack is empty"<<endl;
        exit(1);
    }
    temporary = array[sizeArr - secondstack];
    secondstack--;
    return temporary;
}

template <class T>
class TwoStackOptimal{
    private: 
     int sizeArr;
     int stackone;
     int stacktwo;
     int firststack;
     int secondstack;
     T *array;
     bool isFullStack1();
     bool isFullStack2();
     bool isEmptyStack1();
     bool isEmptyStack2();
    public:
     TwoStackOptimal(int size);
     void pushFlexStack1(T value);
     void pushFlexStack2(T value);
     T popFlexStack1();
     T popFlexStack2();
};

template <class T>
TwoStackOptimal<T>::TwoStackOptimal(int size)
 : sizeArr(size), stackone(0), stacktwo(0), firststack(0), secondstack(0), array(0)
{
    array = new T[sizeArr];
}
template <class T>
bool TwoStackOptimal<T>::isFullStack1(){
    if (secondstack + firststack == sizeArr){
        return true;
    }
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isFullStack2(){
    if (secondstack+firststack == sizeArr){
        return true;
    }
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isEmptyStack1(){
    if (firststack != 0){
        return false;
    }
    return true;
}

template <class T>
bool TwoStackOptimal<T>::isEmptyStack2(){
    if (secondstack != 0){
        return false;
    }
    return true;
}
template <class T>
void TwoStackOptimal<T>::pushFlexStack1(T value){
    if (isFullStack1()){
        cout << "error: first stack is full" << endl;
        return;
    }
    array[firststack]=value;
    firststack++;
}
template <class T>
void TwoStackOptimal<T>::pushFlexStack2(T value){
    if (isFullStack2()){
        cout << "error: second stack is full" << endl;
        return;
    }
    array[(sizeArr - 1)-secondstack]=value;
    secondstack++;
}

template <class T>
T TwoStackOptimal<T>::popFlexStack1(){
    T temporary;
    if (isEmptyStack1()){
        cout << "error: stack is empty" << endl;
        exit(1);
    }
    temporary = array[firststack - 1];
    firststack--;
    return temporary;
}
template <class T>
T TwoStackOptimal<T>::popFlexStack2(){
    T temporary;
    if (isEmptyStack2()){
        cout << "error: stack is empty" << endl;
        exit(1);
    }
    temporary = array[sizeArr - secondstack];
    secondstack--;
    return temporary;
}

template <typename T>
void showTowerStates(int n, stack<T> &A, stack<T> &B, stack<T> &C, char a, char b, char c){
    if (n == 1){
        cout << "Moved " << A.top() << " from peg " << a << " to " << c << endl;
        C.push(A.top());
        A.pop();
        return;
    }
    showTowerStates(n - 1,A,C,B,a,c,b);
    cout << "Moved " << A.top() << " from peg " << a << " to " << c << endl;
    C.push(A.top());
    A.pop();
    
    showTowerStates(n - 1, B, A, C, b, a, c);
}
template <typename T>
void showTowerStates(int n, stack<T> &A, stack<T> &B, stack<T> &C){
    showTowerStates(n,A,B,C,'A','B','C');
    
}
#endif
