//Nishanth Babu
//Sid: 861155514
// used a lot of for loops and while loops inorder the test the run times of sets vs hash tables.used the 
// clock function to time how long it would take to insert into both of these stoarge method and calculated their efficiency based on that.
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <unordered_set>
#include <algorithm>
#include <ctime>
using namespace std;
int main (int argc, char* argv[]){
    vector <string> v; 
    if (argc != 3){
        cout << "too few arguements" << endl;
        exit(-1);
    }
    ifstream fin;
    fin.open(argv[1]);
    if (!fin.is_open()){
        cout << "can't open words.txt" << endl;
        exit(0);
    }
    ofstream fout;
    fout.open(argv[2]);
    if (!fout.is_open()){
        cout << "can't open words.txt" << endl;
        exit(0);
    }
    string wordlist;
    while (fin >> wordlist){ // fills vector with words
        v.push_back(wordlist);
    }
    set<string> s; // creates balanced tree
    set<string>::iterator s_it = s.begin();
    unordered_set <string> us; // creates has table
    vector<vector<double>> treein(10, vector<double> (10));
    vector<vector<double>> hashin(10, vector<double> (10));
    vector<vector<double>> treeq(10, vector<double> (10));
    vector<vector<double>> hashq(10, vector<double> (10));
    vector<double> avgtree(10);
    vector<double> avghash(10);
    vector<double> avgtreeq(10);
    vector<double> avghashq(10);
    double sit = 0.0;
    double usit = 0.0;
    double sqt = 0.0;
    double usqt = 0.0;
    int istart = 0;
    int iend = 0;
    int qstart = 0;
    int qend = 0;
    for (unsigned st = 0; st < 10; ++st){ // has the number of runs
        for (unsigned n = 5000; n <= 50000; n = n + 5000){
            istart = clock(); // clock function used to time how long it will take 
            unsigned j = n - 5000;
            while( j < n){ // insert values into set
                s.insert(s_it, v.at(j));
                j++;
            }
            iend = clock(); // stops timer
            sit = (((float)iend - istart)/CLOCKS_PER_SEC)/n; // average time of insert
            istart = clock(); // timer of unsorted set
            unsigned js = n - 5000;
            while(js < n){
                us.insert(v.at(js));
                js++;
            }
            iend = clock(); 
            usit = (((float)iend - istart) / CLOCKS_PER_SEC)/n; // average unsorted time
            qstart = clock(); // starts time for set
            unsigned jw = n - 5000;    
            while( jw < n){ // looks up the word
                s.find(v.at(jw));
                jw++;
            }
            qend = clock(); 
            sqt = (((float)qend - qstart) / CLOCKS_PER_SEC)/n; // query time;
            qstart = clock(); 
            unsigned ju = n - 5000;
            while( ju < n){
                us.find(v.at(ju));
                ju++;
            }
            qend = clock(); 
            usqt = (((float)qend - qstart) / CLOCKS_PER_SEC)/n;
            unsigned position = (n/5000) - 1; // used to find position in second vector because values are different
            treein.at(st).at(position) = sit;// insert into proper vector
            hashin.at(st).at(position) = usit;
            treeq.at(st).at(position) = sqt;
            hashq.at(st).at(position) = usqt;
        }
        random_shuffle(v.begin(), v.end());
    }
    unsigned y = 0;
    while( y < 10){ //fill the average vectors with times
        double treeque = 0.0;
        double hashque = 0.0;
        double treeinsert = 0.0;
        double hashinsert = 0.0;
        unsigned run = 0;
        while(run < 10){ // keep track of times;
            treeinsert = treeinsert + treein.at(run).at(y);
            hashinsert = hashinsert + hashin.at(run).at(y);
            treeque = treeque + treeq.at(run).at(y);
            hashque = hashque + hashq.at(run).at(y);
            run++;
        }
        // add in values for each type of sort;
        avgtree.at(y) = treeinsert / 10; 
        avghash.at(y) = hashinsert / 10;
        avgtreeq.at(y) = treeque / 10;
        avghashq.at(y) = hashque / 10;
        y++;
    }
    // put everything into a file and output
    for (unsigned i = 0, val = 5000; i < 10; ++i, val = val + 5000){
        fout << val << ' ' << avgtree.at(i) << ' '
            << avghash.at(i) << ' ' 
            << avgtreeq.at(i) << ' ' 
            << avghashq.at(i) << endl;
    }
    fin.close();
    fout.close();
    return 0;
}