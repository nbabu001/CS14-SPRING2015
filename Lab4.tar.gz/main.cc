//Nishanth Babu
// SID: 861155514
// 5/3/15
#include <iostream>
#include <list>
#include "lab4.h"

using namespace std;

int main (int argc, char* argv[])
{
    if (argc != 2){
        cout << "Error: not enough arguments" << endl;
        exit(-1);
    }
    list<coordinate> t1;
    list<coordinate> t2;
    int k = atoi(argv[1]);
    cout << " this is the pre order values" << endl;
    preorder(t1, k);
    print(t1);
    cout << "this is the post order values" << endl;
    postorder(t2, k);
    print(t2);
    cout << "this is the sorted list" << endl;
    sorted(t2);
    return 0;
}
