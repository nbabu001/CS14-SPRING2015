//Nishanth Babu
// SID: 861155514
// 5/3/15
#ifndef lab4_h
#define lab4_h
#include <iostream>
#include <list>
#include <vector>
using namespace std;
struct coordinate{
    int x;
    int y;
    coordinate(int xvalue, int yvalue)
     : x(xvalue), y(yvalue)
    { }
};
typedef pair<int,int> Entry;
class priority_queue{
    public:
     vector<Entry> inputs;
     Entry& front(){ 
         return inputs.back(); 
     }
     void push(Entry input){
         inputs.push_back(input);
         int i = inputs.size() -1;
         for (i = i; i != 0; i--){
             if (inputs[i - 1].first + inputs[i - 1].second > inputs[i].second + inputs[i].first){
                 break;
             }
             swap(inputs[i], inputs[i-1]);
         }
     }
     void print(){
         int i = inputs.size()-1;
         for (i = i; i >= 0; i--){
             cout << inputs.at(i).first <<' '<< inputs.at(i).second << endl;
         }
     }
};
// same as the assignment
void preorderhelp(int m, int n, list<coordinate> &tlist, int k){
    if (k < m + n){
        return;
    }
    coordinate temp(m,n);
    tlist.push_back(temp);
    preorderhelp((2*m)-n, m, tlist, k);
    preorderhelp((2*m)+n, m, tlist, k);
    preorderhelp(m + (2 * n), n, tlist, k);
}
void postorderhelp(int m, int n, list<coordinate> &tlist, int k){
    if (k < m+n){
        return;
    }
    postorderhelp((2 * m) - n, m, tlist, k);
    postorderhelp((2 * m) + n, m, tlist, k);
    postorderhelp(m + (2 * n), n, tlist, k);
    coordinate temp(m,n);
    tlist.push_back(temp);
}
void preorder(list<coordinate> &tlist, int k){
    preorderhelp(2, 1, tlist, k);
    preorderhelp(3, 1, tlist, k);
}
void postorder(list<coordinate> &tlist, int k){
    postorderhelp(2, 1, tlist, k);
    postorderhelp(3, 1, tlist, k);
}
void sorted(list<coordinate> &tlist){
    Entry temp;
    priority_queue prio;
    list<coordinate>::iterator start;
    for (start = tlist.begin(); start != tlist.end(); ++start){
        temp.first = (*start).x;
        temp.second = (*start).y;
        prio.push(temp);
    }
    prio.print();
}
void print(list<coordinate> tlist){
    list<coordinate>::iterator start = tlist.begin();
    for (; start != tlist.end(); ++start){
        cout << (*start).x << ' ' << (*start).y << endl;
    }
}
#endif